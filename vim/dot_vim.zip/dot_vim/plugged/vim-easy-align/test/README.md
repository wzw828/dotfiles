Test cases for vim-easy-align
=============================

### Prerequisite

- [Vader.vim](https://github.com/junegunn/vader.vim)

### Run

```
./run
```

